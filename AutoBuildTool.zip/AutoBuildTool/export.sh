#!/bin/sh

export myvalue="export->wangshengyuan"
echo "$myvalue"

sh export1.sh
