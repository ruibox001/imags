#!/bin/sh

UNAME="wsy"
UPWD="Wsy*_)()2141"
SHELLPATH="/Users/macmini/Desktop/autotool/shell"

echo "测试脚本拉去SVN代码"

cd $SHELLPATH

pwd

rm -rf ../build/*

sleep 2;

svn co https://192.168.1.31/svn/IOS/trunk/Src/SuperHR ../build --username "$UNAME" --password "$UPWD"

echo "测试脚本执行完成了"
